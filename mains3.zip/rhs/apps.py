from django.apps import AppConfig


class RhsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rhs'
